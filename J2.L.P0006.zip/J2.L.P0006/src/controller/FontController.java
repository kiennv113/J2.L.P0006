/*
 Title:            My Text Editor (MTE)
 Semester:         Summer 2021 - BL5
 Author:           Nguyen Van Kien
 Email:            kiennvhe140687@fpt.edu.vn
 CS Login:         kiennvhe140687
 Lecturer's Name:  Tran Binh Duong
 Lab Section:      LAB221
 */
package controller;

import java.awt.GraphicsEnvironment;

/**
 *
 * @author Kien Nguyen
 */
public class FontController {

    /**
     * Function: get all Font name
     *
     * @return a string array  of font name
     */
    
    public String[] getAllFontName() {
                String[] fontNames = GraphicsEnvironment .getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
                return fontNames;
    }
    
}
